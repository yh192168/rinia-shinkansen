# -*- coding: utf-8 -*-
QUESTION_COUNT=10
DEFAULT_PORT=5001
SPEEDS_KMH={"初級":450,"中級":500,"上級":603}
STATIONS=[("品川",0),("神奈川県駅",10),("山梨県駅",80),("長野県駅",180),("岐阜県駅",260),("名古屋",286)]
def format_seconds(seconds):
    seconds=int(round(seconds)); m,s=divmod(seconds,60); return f"{m}:{s:02d}"
def parse_time_to_seconds(t):
    try:
        m,s=t.split(':'); return int(m)*60+int(s)
    except Exception: return 0
def calc_distance_km(difficulty, elapsed_seconds):
    return round(SPEEDS_KMH.get(difficulty,450)*(elapsed_seconds/3600),1)
def judge_station(distance_km):
    cur=STATIONS[0][0]
    for name,km in STATIONS:
        if distance_km>=km: cur=name
        else: break
    return cur
