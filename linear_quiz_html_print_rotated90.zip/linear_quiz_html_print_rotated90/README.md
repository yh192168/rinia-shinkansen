# 🚄 LINEAR QUIZ CHALLENGE HTML版 印刷90度回転版

シールが横向きで出たため、印刷方向を前回設定からさらに90度回転させた版です。

## 変更点

- `server/printer.py` の印刷回転を変更
- 従来 `rotate='90'` 相当から、今回は `PRINT_ROTATE='180'`
- Pillow 10以降対応の `Image.ANTIALIAS` パッチ入り
- `DRY_RUN=False` のため実機印刷します

## 起動

```bash
cd ~/Downloads/linear_quiz_html_print_rotated90
python3 -m pip install -r requirements.txt
sudo python3 -m server.server
```

USB権限の関係で、QL-800印刷時は `sudo` 起動を推奨します。

ランキング画面：

```text
http://localhost:5001
```

WindowsクイズURL：

```text
http://MacのIP:5001/play
```

## もし逆向き・別方向だった場合

`server/printer.py` の以下を変更してください。

```python
PRINT_ROTATE='180'
```

候補：

```python
PRINT_ROTATE='0'
PRINT_ROTATE='90'
PRINT_ROTATE='180'
PRINT_ROTATE='270'
```
