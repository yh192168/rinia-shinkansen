# -*- coding: utf-8 -*-
from PIL import Image

# Pillow 10以降で削除された Image.ANTIALIAS を brother_ql 用に復活させる
if not hasattr(Image, "ANTIALIAS"):
    Image.ANTIALIAS = Image.Resampling.LANCZOS

DRY_RUN=False
PRINTER_MODEL='QL-800'
PRINTER_IDENTIFIER='usb://0x04f9:0x209b'
LABEL='62'

# 前回の印刷が横向きだったため、現在の印刷設定からさらに90度回転させた設定です。
# brother_ql の rotate は絶対角度指定なので、従来 rotate='90' から rotate='180' に変更しています。
PRINT_ROTATE='180'

def print_sticker(image_path):
    if DRY_RUN:
        print('[DRY_RUN] Sticker image generated:', image_path)
        return True
    try:
        from brother_ql.conversion import convert
        from brother_ql.backends.helpers import send
        from brother_ql.raster import BrotherQLRaster
        qlr=BrotherQLRaster(PRINTER_MODEL)
        instructions=convert(
            qlr=qlr,
            images=[str(image_path)],
            label=LABEL,
            rotate=PRINT_ROTATE,
            threshold=70.0,
            dither=False,
            compress=False,
            red=False,
            dpi_600=False,
            hq=True,
            cut=True,
        )
        send(instructions=instructions, printer_identifier=PRINTER_IDENTIFIER, backend_identifier='pyusb', blocking=True)
        print(f'[PRINTED] Sticker sent to Brother QL-800 rotate={PRINT_ROTATE}:', image_path)
        return True
    except Exception as e:
        print('Print error:', e)
        return False
