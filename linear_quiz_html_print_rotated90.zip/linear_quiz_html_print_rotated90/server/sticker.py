# -*- coding: utf-8 -*-
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import qrcode, json
OUT_DIR=Path(__file__).resolve().parent/'stickers'; OUT_DIR.mkdir(exist_ok=True)
W,H=732,1654
def font(sz):
    for p in ['/System/Library/Fonts/ヒラギノ角ゴシック W6.ttc','/System/Library/Fonts/Helvetica.ttc','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf']:
        try:
            if Path(p).exists(): return ImageFont.truetype(p,sz)
        except Exception: pass
    return ImageFont.load_default()
def center(d,y,t,f,fill):
    box=d.textbbox((0,0),str(t),font=f); d.text(((W-(box[2]-box[0]))//2,y),str(t),font=f,fill=fill)
def generate_sticker(data, rank_type='STANDARD'):
    colors={'GOLD':(212,175,55),'SILVER':(185,190,196),'BRONZE':(205,127,50),'STANDARD':(0,229,255)}; ac=colors.get(rank_type,colors['STANDARD']); white=(235,252,255)
    img=Image.new('RGB',(W,H),(7,20,35)); d=ImageDraw.Draw(img); d.rounded_rectangle((30,30,W-30,H-30),36,outline=ac,width=8)
    center(d,80,'LINEAR QUIZ',font(64),ac); center(d,155,'完走証',font(54),white); center(d,270,rank_type,font(46),ac)
    y=360
    for lab,val in [('ニックネーム',data.get('nickname','')),('難易度',data.get('difficulty','')),('正解数',f"{data.get('score','')} / 10"),('タイム',data.get('time','')),('進んだ距離',f"{data.get('distance','')}km"),('到達駅',data.get('station',''))]:
        center(d,y,lab,font(34),(160,220,230)); y+=45; center(d,y,val,font(50),white); y+=95
    center(d,y+10,'SCMaglev',font(44),ac); qr=qrcode.make(json.dumps(data,ensure_ascii=False)).convert('RGB').resize((260,260)); img.paste(qr,((W-260)//2,H-350))
    safe=''.join(c for c in data.get('nickname','player') if c.isalnum() or c in '_-')[:20] or 'player'; path=OUT_DIR/f'sticker_{safe}_{rank_type}.png'; img.save(path); return path
