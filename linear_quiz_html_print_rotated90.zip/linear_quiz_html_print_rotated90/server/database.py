# -*- coding: utf-8 -*-
import sqlite3
from pathlib import Path
from datetime import datetime
from common.constants import parse_time_to_seconds
DB_PATH=Path(__file__).resolve().parent/'ranking.db'
def connect(): return sqlite3.connect(DB_PATH)
def init_db():
    with connect() as con:
        con.execute("CREATE TABLE IF NOT EXISTS results(id INTEGER PRIMARY KEY AUTOINCREMENT,nickname TEXT,difficulty TEXT,score INTEGER,time TEXT,time_seconds INTEGER,distance REAL,station TEXT,rank_type TEXT DEFAULT 'STANDARD',created_at TEXT)"); con.commit()
def insert_result(d):
    init_db()
    with connect() as con:
        cur=con.execute('INSERT INTO results(nickname,difficulty,score,time,time_seconds,distance,station,created_at) VALUES(?,?,?,?,?,?,?,?)',(d['nickname'],d['difficulty'],int(d['score']),d['time'],parse_time_to_seconds(d['time']),float(d['distance']),d['station'],datetime.now().isoformat(timespec='seconds'))); con.commit(); return cur.lastrowid
def today_ranking(limit=20):
    init_db(); today=datetime.now().date().isoformat()
    with connect() as con:
        con.row_factory=sqlite3.Row
        return [dict(r) for r in con.execute('SELECT * FROM results WHERE substr(created_at,1,10)=? ORDER BY distance DESC,score DESC,time_seconds ASC,created_at ASC LIMIT ?',(today,limit)).fetchall()]
def rank_for_id(rid):
    for i,r in enumerate(today_ranking(9999),1):
        if r['id']==rid: return i
    return None
def rank_type_for_rank(r): return {1:'GOLD',2:'SILVER',3:'BRONZE'}.get(r,'STANDARD')
def update_rank_type(rid,typ):
    with connect() as con: con.execute('UPDATE results SET rank_type=? WHERE id=?',(typ,rid)); con.commit()
